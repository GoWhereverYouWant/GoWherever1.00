# Android加密工具库 EncryptionLib
### 对Android中常用的加密方式进行封装，包含以下加密：
#### 1.DES
#### 2.3DES
#### 3.AES
#### 4.XOR 
#### 5.SHA
#### 6.Base64
#### 7.RAS
##### （1）填充式加密
##### （2）分段式加密
#### 8.MD5
##### （1）多次加密
##### （2）加盐加密，可自定义key盐值
### 使用方式
##### 将该库作为module lib 导入现有项目中即可。
#### 算法详细介绍浏览：http://blog.csdn.net/u013718120/article/details/56486408
